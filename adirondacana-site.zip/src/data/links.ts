// The Links page is built from this list. Add, remove, or reorder entries freely.
// These three are examples: replace them with the sites you actually want to share.
export const links = [
  {
    title: 'Adirondack Mountain Club',
    url: 'https://www.adk.org/',
    description: 'Trail guides, local chapters, and volunteer trips across the Adirondack Park.',
  },
  {
    title: 'Adirondack 46ers',
    url: 'https://www.adk46r.org/',
    description: 'A club for hikers working on the 46 High Peaks, with stewardship and trail information.',
  },
  {
    title: 'NYS Department of Environmental Conservation',
    url: 'https://dec.ny.gov/',
    description: 'Regulations, alerts, and conditions for state land in the Adirondacks.',
  },
];
