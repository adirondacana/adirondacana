import { getCollection } from 'astro:content';

// All published posts, newest first. Drafts show up in `npm run dev`
// but are left out of the live site.
export async function getPosts() {
  const posts = await getCollection('posts', ({ data }) =>
    import.meta.env.PROD ? !data.draft : true,
  );
  return posts.sort((a, b) => b.data.date.valueOf() - a.data.date.valueOf());
}
