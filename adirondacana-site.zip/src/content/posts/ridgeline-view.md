---
title: "A long view across the ridgeline"
description: "A second sample post, with a wide panorama and a photo inside the text."
date: 2026-10-05
cover: ../../assets/photos/ridgeline-panorama.jpg
coverAlt: "A wide view from a summit across forested ridges under a pale blue sky."
---

Another sample post. Wide photos like the panorama above show in full, without cropping.

Photos can also sit inside the text. Put the file in `src/assets/photos` and add a line like this where you want it:

`![Describe the photo here](../../assets/photos/your-photo.jpg)`

Photos inside a post stretch to the full width of the page, while the text stays in a narrower column.

![A hiker in a teal jacket crosses a snowy ridge toward a fog-covered summit.](../../assets/photos/snowy-summit.jpg)

Quotes are set apart like this:

> We do not go to the green woods and crystal waters to rough it, we go to smooth it.
