---
title: "Into the clouds"
description: "A sample post showing how a page looks. Replace it with your own writing."
date: 2026-10-20
cover: ../../assets/photos/snowy-summit.jpg
coverAlt: "A hiker in a teal jacket walks across snow-dusted rock toward a summit hidden in fog."
coverPosition: "50% 30%"
---

This is a sample post, here so you can see how a page reads on the finished site. Replace it with your own writing, or delete this file once your first real post is up.

The photo above shows a ridge dusted with early snow and fog closing in on the summit ahead. Long paragraphs like this one are set in a book typeface at a comfortable width, so they stay easy to read on a phone or a large monitor.

## Writing a post

Each post is one Markdown file in `src/content/posts`. The block between the dashes at the top holds the details:

- `title` and `description` appear in the post list and in link previews.
- `date` sets the order. Newest posts come first.
- `cover` and `coverAlt` add the large photo at the top.
- `draft: true` keeps a post off the live site while you work on it.
