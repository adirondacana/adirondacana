import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

// Every blog post is a Markdown file in src/content/posts.
// The fields between the --- lines at the top of each file are described here.
const posts = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/posts' }),
  schema: ({ image }) =>
    z
      .object({
        title: z.string(),
        // One or two sentences. Shown in post lists and when the post is shared.
        description: z.string(),
        // Written as 2026-10-20
        date: z.coerce.date(),
        // Optional cover photo, e.g. ../../assets/photos/my-photo.jpg
        cover: image().optional(),
        // Required when there is a cover. Describes the photo for screen readers.
        coverAlt: z.string().optional(),
        // Optional crop focus for tall photos, e.g. "50% 30%" (x y)
        coverPosition: z.string().optional(),
        // Set to true to hide a post from the live site while you work on it.
        draft: z.boolean().default(false),
      })
      .refine((post) => !post.cover || Boolean(post.coverAlt), {
        message: 'Add a coverAlt that describes the cover photo.',
        path: ['coverAlt'],
      }),
});

export const collections = { posts };
